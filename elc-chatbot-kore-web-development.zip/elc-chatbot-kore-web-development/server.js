// Variables
var path = require('path');
var express = require('express');
var serveStatic = require('serve-static');
var app = require('express')();
var http = require('http').Server(app);

//Configure port
var port=3003;

//App directories
var PROJECT_DIR = path.normalize(__dirname);

app.all('*', function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    next();
});

//app.use('/',express.static(path.join(PROJECT_DIR, '')));
//app.use(serveStatic('./', { 'index': ['default.html', 'default.htm', 'index.html'] }))
app.use(serveStatic('./', {
    maxAge: '1d',
    setHeaders: setCustomCacheControl
}));

http.listen(port, function(){
    console.log('Sample Application runnning at http://localhost:'+port+'/UI');
});

function setCustomCacheControl (res, path) {
    res.setHeader('Cache-Control', 'public, max-age=1d')
}