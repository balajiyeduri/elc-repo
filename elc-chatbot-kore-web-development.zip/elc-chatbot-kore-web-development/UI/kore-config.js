(function(KoreSDK){
    var koreBotList = {
        "st-6e774a52-71b9-5144-ae11-dbafb5ab497e": {
            "botId": "st-6e774a52-71b9-5144-ae11-dbafb5ab497e",
            "botName": "ELC Bot"
        }
    };

    var KoreSDK=KoreSDK||{};
    
    //load custom data from the web page
    var webData = {};
    var pageInfo = document.getElementById('ttec-page-info');
    if(pageInfo) {
        var pageDataset = pageInfo.dataset;
        if (pageDataset) {
            var ttecPageName = pageDataset.ttecPageName;
            if (ttecPageName)
                webData.ttecPageName = ttecPageName;
            var ttecPageCategory = pageDataset.ttecPageCategory;
            if (ttecPageCategory)
                webData.ttecPageCategory = ttecPageCategory;
            var ttecPageCreateDate = pageDataset.ttecPageCreateDate;
            if (ttecPageCreateDate)
                webData.ttecPageCreateDate = ttecPageCreateDate;
            var ttecEnvType = pageDataset.ttecEnvType;
            if (ttecEnvType)
                webData.ttecEnvType = ttecEnvType;
        }
    }

    //load the bot-id from the web page
    var koreBotInfo = {};
    var chatContainerElement = document.getElementById('chatContainer');
    if(chatContainerElement) {
        var chatContainerDataset = chatContainerElement.dataset;
        if(chatContainerDataset) {
            botId = chatContainerDataset.koreBotId;
            if(!botId)
                botId = Object.keys(koreBotList);
            koreBotInfo = koreBotList[botId];
        }
    }

    var webContext = {};
    var pageUrl = window.location.href;
    if(pageUrl)
        webContext.pageUrl = pageUrl;
    var pageTitle = document.title;
    if(pageTitle)
        webContext.pageTitle = pageTitle;
    
     /* Updates to fetch oracle ID from Div */
     var oracle_ID = document.currentScript.id;
     webContext.oracle_id = oracle_ID;
     /* End of change */

    var customData =  {
        webData: webData,
        webContext: webContext,
        "ttcOrganization": "Customer Support",
        "ttcTitle": "Insurance Assistant",
        "ttcLocation": "Manilla",
        "ttcCountryCode": "PH",
        "ttcLanguage": "en",
        "ttcTZ": "PDT",
        "ttcTimeAwayType": [
            "Vacation",
            "PC Holiday",
            "PTO",
            "National Holiday",
            "Floating Holiday"
        ],
        "ttcPTOTypes": [
            { "code": "ILL", "description": "Illness"},
            { "code": "BER", "description": "Bereavement" },
            { "code": "MAT", "description": "Maternity Leave"},
            { "code": "PAT", "description": "Paternity Leave"},
            { "code": "STMD", "description": "Short Term Disability"},
            { "code": "LTMD", "description": "Long Term Disability"}
        ]
    };

    var botOptions = {};
    botOptions.logLevel = 'debug';
    botOptions.koreAPIUrl = "https://bots.kore.ai/api/";
    //botOptions.koreAPIUrl = "https://pilot-bots.kore.ai/api/";
    botOptions.koreSpeechAPIUrl = "";//deprecated
    //botOptions.bearer = "bearer xyz-------------------";
    //botOptions.ttsSocketUrl = '';//deprecated
    botOptions.koreAnonymousFn = koreAnonymousFn;
    botOptions.recorderWorkerPath = '../libs/recorderWorker.js';
    botOptions.JWTUrl = "https://ttec-kore-jwt.azurewebsites.net/users/sts";
    botOptions.userIdentity = 'mike.piotrowski@kore.com';// Provide users email id here

    //first load default data
    botOptions.botInfo = {
        name: "ELC Bot",
        "_id": "st-6e774a52-71b9-5144-ae11-dbafb5ab497e",
        customData: customData
    }; // bot name is case sensitive
    //botOptions.clientId = "cs-3a2c43b8-ea02-5060-a9cb-092996d6fd47";
    //botOptions.clientSecret = "N+i1AlFQfPeLQy8VsxxSPq+UKDEskfnPswIjFW8tDa4=";
    botOptions.botId = botOptions.botInfo._id;
	//now load if specified on the web page
    if(koreBotInfo) {
        botOptions.botInfo.name = koreBotInfo.botName;
        botOptions.botInfo["_id"] = koreBotInfo.botId;
        botOptions.botId = koreBotInfo.botId;
        //botOptions.clientId = koreBotInfo.clientId;
        //botOptions.clientSecret = koreBotInfo.clientSecret;
    }

// To modify the web socket url use the following option
// botOptions.reWriteSocketURL = {
//     protocol: 'PROTOCOL_TO_BE_REWRITTEN',
//     hostname: 'HOSTNAME_TO_BE_REWRITTEN',
//     port: 'PORT_TO_BE_REWRITTEN'
// };
    
    var chatConfig={
        botOptions:botOptions,
        allowIframe: false, 			// set true, opens authentication links in popup window, default value is "false"
        isSendButton: true, 			// set true, to show send button below the compose bar
        isTTSEnabled: false,			// set true, to hide speaker icon
        ttsInterface:'webapi',        // webapi or awspolly , where default is webapi
        isSpeechEnabled: false,			// set true, to hide mic icon
        allowGoogleSpeech: true,		// set true, to use Google speech engine instead KORE.AI engine.This feature requires valid Google speech API key. (Place it in 'web-kore-sdk/libs/speech/key.js')
        allowLocation: false,			// set false, to deny sending location to server
        loadHistory: true,				// set true to load recent chat history
        messageHistoryLimit: 30,		// set limit to load recent chat history
        autoEnableSpeechAndTTS: false, 	// set true, to use talkType voice keyboard.
        graphLib: "d3" ,				// set google, to render google charts.This feature requires loader.js file which is available in google charts documentation.
        googleMapsAPIKey:"",
        minimizeMode:true,              // set true, to show chatwindow in minized mode
        supportDelayedMessages:false,    // enable to add support for renderDelay in message nodes which will help to render messages with delay from UI       
        pickersConfig:{
            showDatePickerIcon:false,           //set true to show datePicker icon
            showDateRangePickerIcon:false,      //set true to show dateRangePicker icon
            showClockPickerIcon:false,          //set true to show clockPicker icon
            showTaskMenuPickerIcon:false,       //set true to show TaskMenu Template icon
            showradioOptionMenuPickerIcon:false //set true to show Radio Option Template icon
        }
    };
     /* 
        allowGoogleSpeech will use Google cloud service api.
        Google speech key is required for all browsers except chrome.
        On Windows 10, Microsoft Edge will support speech recognization.
     */

    KoreSDK.chatConfig=chatConfig
})(window.KoreSDK);
