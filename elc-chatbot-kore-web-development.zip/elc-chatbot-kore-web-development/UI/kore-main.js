(function($){

    $(document).ready(function () {
        function assertion(options, callback) {
            //var user = $(document).selectUsers.val();
            //var user = $("#selectUsers").val();
            var pathname = $(location).attr('pathname');
            var href = $(location).attr('href');
            //var pathLocation = href.indexOf('?oracle_id=');
            //if(pathLocation >= 0)
                //var user = href.substring(pathLocation + 11);
            //else {
                //var user = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
                    //var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
                    //return v.toString(16);
                //});
            //}
            //                "clientId": options.clientId,
            //                 "clientSecret": options.clientSecret,
            //                "botId": options.botId,

            //First Generate a GUID - if there is no cookie "kore_user_guid" set then we will save this value in the cookie
            var user = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
                var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });
            //now check for the cookie "kore_user_guid"
            var cookieName = 'kore_user_guid=';
            var decodedCookies = decodeURIComponent(document.cookie).split(';');
            var cookieGuid = null;
            for(var i = 0; i <decodedCookies.length; i++) {
                var c = decodedCookies[i];
                while (c.charAt(0) === ' ') {
                    c = c.substring(1);
                }
                if (c.indexOf(name) === 0) {
                    cookieGuid = c.substring(name.length, c.length);
                    break;
                }
            }
            if(cookieGuid)
                user = cookieGuid.substring('kore_user_guid='.length);
            //set the cookie - if it's there this will refresh the expiration
            var cookieDate = new Date();
            cookieDate.setTime(cookieDate.getTime() + (90*24*60*60*1000));
            var expires = "expires="+ cookieDate.toUTCString();
            document.cookie = 'kore_user_guid=' + user + ';' + expires + ';path=/';
            var jsonData = {
                "botId": options.botId,
                "identity": user,
                "aud": "",
                "isAnonymous": false
            };
            $.ajax({
                url: options.JWTUrl,
                type: 'post',
                data: jsonData,
                dataType: 'json',
                success: function (data) {
                    options.assertion = data.jwt;
                    options.handleError = koreBot.showError;
                    options.chatHistory = koreBot.chatHistory;
                    options.botDetails = koreBot.botDetails;
                    callback(null, options);
                    setTimeout(function () {
                        if (koreBot && koreBot.initToken) {
                            koreBot.initToken(options);
                        }
                    }, 2000);
                },
                error: function (err) {
                    koreBot.showError(err.responseText);
                }
            });
        }

        var chatConfig=window.KoreSDK.chatConfig;
        chatConfig.botOptions.assertionFn=assertion;
        
        var koreBot = koreBotChat();
        koreBot.show(chatConfig);
        $('.openChatWindow').click(function () {
            koreBot.show(chatConfig);
        });
    });

})(jQuery || (window.KoreSDK && window.KoreSDK.dependencies && window.KoreSDK.dependencies.jQuery));