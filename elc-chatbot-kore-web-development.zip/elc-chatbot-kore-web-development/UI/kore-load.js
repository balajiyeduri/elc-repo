function loadjscssfile(filename) {
    var filetype = filename.endsWith('.js') ? 'js' : filename.endsWith('css') ? 'css' : 'other';
    if (filetype == "js") { //if filename is a external JavaScript file
        if (filename.endsWith('kore-config.js')) {

            var fileref = document.createElement('script');
            fileref.setAttribute("type", "text/javascript");
            fileref.setAttribute("src", filename);

            /* Updates to fetch oracle ID from Div or Script tag*/
            var oracle_div = document.getElementById('ttec-page-info');
            var oracle_div_data = "";
            if (oracle_div) {
                oracle_div_data = String(oracle_div.innerHTML);
                oracle_div_data = oracle_div_data.trim();
                oracle_div_data = oracle_div_data.match(/^\d{7}$/);
            }
            var oracle_script = document.currentScript.src;
            var oracle_script_data = "";
            var oracle_ID_Data = oracle_script.split("?oracle_id=");
            //fetch id from script tag
            if (oracle_ID_Data.length == 2 && oracle_div_data == null) {
                oracle_script_data = oracle_ID_Data[1].substring(0, 7);
                oracle_script_data = oracle_script_data.match(/^\d{7}$/);
                if (oracle_script_data != null) {
                    fileref.setAttribute("id", oracle_script_data);
                } else {
                    fileref.setAttribute("id", "Failed to fetch Oracle ID");
                }
            } else {
                fileref.setAttribute("id", "Failed to fetch Oracle ID");
            }
            //ask now
            if (oracle_div_data != null) {
                fileref.setAttribute("id", oracle_div_data);
            } else {
                fileref.setAttribute("id", "Failed to fetch Oracle ID");
            }
            //fallback block
            if ((oracle_script_data == "" && oracle_div_data == "") || (oracle_script_data == null && oracle_div_data == null)) {
                fileref.setAttribute("id", "Failed to fetch Oracle ID");
            }
            /* End of custom changes */
            fileref.async = false;
        } else {
            var fileref = document.createElement('script');
            fileref.setAttribute("type", "text/javascript");
            fileref.setAttribute("src", filename);
            fileref.async = false;
        }

    } else if (filetype == "css") { //if filename is an external CSS file
        var fileref = document.createElement("link");
        fileref.setAttribute("rel", "stylesheet");
        fileref.setAttribute("type", "text/css");
        fileref.setAttribute("href", filename);
        fileref.async = false;
    }
    if (typeof fileref != "undefined")
        document.getElementsByTagName("head")[0].appendChild(fileref);


}

//update for the TTec server location
var base = './';

loadjscssfile(base + 'libs/kore-no-conflict-start.js');
loadjscssfile(base + "libs/jquery.js");
loadjscssfile(base + "libs/jquery.tmpl.min.js");
loadjscssfile(base + "libs/jquery-ui.min.js");
loadjscssfile(base + "libs/jquery-ui.min.css");
loadjscssfile(base + "libs/moment.js");
loadjscssfile(base + "../libs/ie11CustomProperties.js");
loadjscssfile(base + "../libs/lodash.min.js");
loadjscssfile(base + "../libs/d3.v4.min.js");
loadjscssfile(base + "../libs/KoreGraphAdapter.js");
loadjscssfile(base + '../libs/anonymousassertion.js');
loadjscssfile(base + "../kore-bot-sdk-client.js");
loadjscssfile(base + "chatWindow.js");
loadjscssfile(base + "libs/jquery.daterangepicker.js");
loadjscssfile(base + "libs/daterangepicker.css");
loadjscssfile(base + "libs/jquery-clockpicker.js");
loadjscssfile(base + "libs/jquery-clockpicker.css");
loadjscssfile(base + "../libs/kore-pickers.css");
loadjscssfile(base + "../libs/kore-pickers.js");
loadjscssfile(base + "../libs/emoji.js");
loadjscssfile(base + "../libs/recorder.js");
loadjscssfile(base + "../libs/recorderWorker.js");
loadjscssfile(base + "chatWindow.css");
loadjscssfile(base + "../libs/emojione.sprites.css");
loadjscssfile(base + "../libs/purejscarousel.css");
loadjscssfile(base + "../libs/purejscarousel.js");
loadjscssfile(base + "custom/customTemplate.js");
loadjscssfile(base + "custom/customTemplate.css");
loadjscssfile(base + "kore-config.js");
loadjscssfile(base + "kore-main.js");
loadjscssfile(base + "libs/kore-no-conflict-end.js");